%
% function Y = MyAffine(X, M, method, centre)
%
% Apply the affine transform M to the image or volume X.
% method must be one of 'nearest', 'linear', or 'cubic'.
%
% M is a 4x4 affine matrix with respect to Matlab index coordinates.
% ie. the centre of rotation is, by default, the pixel above and to the
% left of pixel (1,1) or (1,1,1).
% Its last last row of M should be [0 0 0 1].
% The affine transform is an image operator, not a vector operator.
%
% ctr (optional) must be 'centred' or 'topleft' (default).
% The centre is defined as
%
%      ctr = ceil( (size(X)+1) / 2 );
%
function Y = MyAffine(X, M, method, centre)
    
    if nargin==4
        if strcmp(centre,'centred')==1
            ctr = ceil( (size(X)+1) / 2 );
            if numel(ctr)==2
                ctr = [ctr 0];
            end
            %ctr = [1 1 1   0 0 0  0 0 0  ctr];
            ctr = [0 0 0 ctr];
            T = p2m(ctr);
            M = T * M / T;
        end
    end
    
    %[nrows ncold] = size(X);
    %ctr = floor( (size(X) + 1) / 2 );
    if (sum(sum(M~=eye(4)))~=0)

        if length(size(X))==2
            
            % 2D dataset
            
            P = [0 1 0 0;1 0 0 0;0 0 1 0;0 0 0 1]; %swap x<->y (row<->col)
            R = M';
            Mtemp = P * R * P;
            Mtemp = Mtemp([1 2 4],[1 2 4]);
            tform = maketform('affine', Mtemp);
            method2 = 'bilinear';
            if strcmp(method,'nearest')
                method2 = 'nearest';
            elseif strcmp(method,'cubic')
                method2 = 'bicubic';
            end
            Y = imtransform(X, tform, method2, 'XData', [1 size(X,2)], 'YData', [1 size(X,1)]);
            
        else
            
            % 3D dataset
            
            P = eye(4);
            %P = [0 1 0 0;1 0 0 0;0 0 1 0;0 0 0 1]; %swap x<->y (row<->col)
            Mtemp = P * M' * P;
            tform = maketform('affine', double(Mtemp));
            R = makeresampler(method, 'fill');
            TDIMS_A = [1 2 3];
            TDIMS_B = TDIMS_A; % Keep it simple, stupid
            TSIZE_B = size(X);
            Y = tformarray(X,tform,R,TDIMS_A,TDIMS_B,TSIZE_B,[],0);
        end
    else
        Y = X;
    end
