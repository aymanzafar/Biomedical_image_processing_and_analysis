% function params = m2p(HTM)
%    HTM - homogeneous transformation matrix (4x4)
%    params - return value is a row vector of the form
%             [Rx Ry Rz Tx Ty Tz]
%%%% [5] marks total %%%%
function params = m2p(HTM)


    % extracting the shift in the x-, y- and z-direction
    % [1]
    params(4) = HTM(1,4);
    params(5) = HTM(2,4);
    params(6) = HTM(3,4);

    % HTM contains the Rotation matrix R = Rz*Ry*Rx where
    % Rx = [1 0 0; 0 cos(ThetaX) -sin(ThetaX); 0 sin(ThetaX) cos(ThetaX)];
    % Ry = [cos(ThetaY) 0 sin(ThetaY); 0 1 0; -sin(ThetaY) 0 cos(ThetaY)];
    % Rz = [cos(ThetaZ) -sin(ThetaZ) 0; sin(ThetaZ) cos(ThetaZ) 0; 0 0 1];
    % Multiplying Rz*Ry*Rx gives us:
    %
    % R(1,1) = cos(ThetaY)*cos(ThetaZ);
    % R(1,2) = sin(ThetaX)*sin(ThetaY)*cos(ThetaZ)-sin(ThetaZ)*cos(ThetaX);
    % R(1,3) = sin(ThetaX)*sin(ThetaZ)+sin(ThetaY)*cos(ThetaX)*cos(ThetaZ);
    % R(1,4) = 0;
    % R(2,1) = sin(ThetaZ)*cos(ThetaY);
    % R(2,2) = cos(ThetaX)*cos(ThetaZ)+sin(ThetaX)*sin(ThetaY)*sin(ThetaX)
    % R(2,3) = sin(ThetaX)*cos(ThetaY);
    % R(2,4) = 0;
    % R(3,1) = -sin(ThetaY);
    % R(3,2) = sin(ThetaX)*cos(ThetaY);
    % R(3,3) = cos(ThetaX)*cos(ThetaY);
    % R(3,4) = 0;
    % R(4,1) = 0;
    % R(4,2) = 0;
    % R(4,3) = 0;
    % R(4,4) = 1

    % IMPORTANT: We have to keep track of the ThetaY value. If ThetaY=90 then
    % cos(ThetaY) is zero (we can't divide by zero) thus
    % since R(3,1) = -sin(ThetaY)= HTM(3,1) then we get that:
    ThetaY = -asin(HTM(3,1))*180/pi; % [1] note that ThetaY is expressed in degrees

    if(ThetaY ~= 90) % we are fine  

        % [1] for ThetaX
        ThetaX = atan2((HTM(3,2)/cosd(ThetaY)),(HTM(3,3)/cosd(ThetaY)));
        % we need to divide by thetaY to determine the quadrant of the result

        % [1] for ThetaZ
        ThetaZ = atan2((HTM(2,1)/cosd(ThetaY)),(HTM(1,1)/cosd(ThetaY)));
        
    else
        % we are dealing with a 90 deg angle - encountered Gimbal lock (ThetaZ
        % and ThetaX are linked) and theoretically there are infinite number of
        % solutions to this problem. However, we are only interested in one
        % solution which we will obtain by setting ThetaZ to 0 and computing
        % ThetaX
        % [2] for handling this case
        ThetaZ = 0;
        ThetaX = atan2(HTM(1,2),HTM(1,3));
    end

    params(1) = ThetaX *180/pi;
    params(2) = ThetaY; % *180/pi;
    params(3) = ThetaZ *180/pi;

    % basically [4 marks] for the angles, and [1 mark] for translations
    
    % not returning degrees [-1]
    % wrong forumula for angles [-1] for each incorrect angle
    % 

