% function M = p2m([R1 R2 R3 T1 T2 T3])
%
%   Converts motion parameters to a 4x4 homogeneous transformation matrix.
%   The order of operations is:
%     (1) rotate about axis 1, then axis 2, then axis 3
%     (2) translate
%
%   Rotation angles are in degrees
%
%%% [5] marks total %%%
function M = p2m(p)

    % [2 marks] for the rotation part (note the order)
    M = [1     0           0       0;
        0 cosd(p(1))  -sind(p(1))  0;
        0 sind(p(1))   cosd(p(1))  0;
        0      0           0       1];

    M = [cosd(p(2)) 0  sind(p(2))  0;
        0           1         0    0;
        -sind(p(2)) 0  cosd(p(2))  0;
        0           0         0    1] * M;

    M = [cosd(p(3)) -sind(p(3))  0 0;
        sind(p(3))   cosd(p(3))  0 0;
        0                0       1 0;
        0                0       0 1] * M;

    % [1 marks] for the translation part
    T = eye(4);
    T(1:3,4) = reshape(p(4:6),3,1);
    
    % [2 mark] for putting together rotations and translations
    M = T * M;
    
    % if wrong order of operations (eg. R*T) [-2 marks]
    % if rotations in wrong direction [-1 mark]
    % if wrong rotation matrices [-2 marks]

