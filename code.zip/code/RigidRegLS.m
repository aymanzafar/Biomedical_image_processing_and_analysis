% function best_m = RigidRegLS(f, g, m0)
%
% Least squares registration of f to g, using a Newton fixed-point
% iteration.
%
% Input
%   f and g are images (volumes) that are the same size
%   m0 is the initial guess for the motion parameters
%      (default [0 0 0 0 0 0])
%
% Output
%   m is the set of motion parameter estimates, in the form
%
%     m = [theta_r theta_c theta_s r c s]
%
%  where the transformation is with respect to Matlab index coordinates
%  centred on the image (volume) centre (see the help for MyAffine).
%
% [9] marks total
% ----------
% [1] for code clarity
function best_m = RigidRegLS(f, g, m0)

    % Initial motion estimate
    if nargin<3
        % No initial guess? Use identity mapping.
        best_m = [0 0 0 0 0 0];
    else
        best_m = m0; % Initial guess supplied by user
    end

    % Sort out how many dimensions the input is
    dims = size(f);
    ndims = length(dims);
    % If dims are [M N 1], then change that to [M N] (ie. 2D).
    if ndims==3 && dims(3)==1
        dims = dims(1:2);
        ndims = 2;
    end
    
    % Allocate A matrix to hold the partial derivatives
    A = zeros(length(f(:)),ndims);
    
    % Here is how we compute A from g (only once... faster)
    % The marks are listed inside loop.
    % [1] for computing derivatives
    % [1] for putting them in a matrix
    switch ndims
        case 3
            for p = 1:6
                A(:,p) = reshape( MyDerivative(g,p), length(g(:)), 1);
            end
        case 2
            for p = 3:5
                A(:,p-2) = reshape( MyDerivative(g,p), length(f(:)), 1);
            end
    end
    
    
    keep_going = 1; % convergence flag (=0 --> stop)
    counter = 0;
    f_copy = f; % Create a working copy of f
    m = best_m'; % m wi
    

    % [1] for loop with 2 stopping criteria
    while keep_going && counter<20

        % Apply current best motion estimate to f
        % [1] must apply to original f, and 'centred'
        f_copy = MyAffine(f, p2m(best_m), 'linear','centred');

        % Compute the partial derivatives and store them in columns of A
        switch ndims
            
            % More marks are given for 3D case
            % [1] for 2D case also
            case 3 % 3D
                % Compute LS solution to linearized registration problem
                % m = (A'*A) \ (A' * (g(:) - f_copy(:)));
                % This could also be implemented using backslash
                % [2]
                m = A \ (g(:) - f_copy(:));
                
            case 2 % 2D
                                
                m(3:5) = A \ (g(:) - f_copy(:));
                
        end

        % Increment the current motion estimate
        % [1] for incrementing best-guess
        best_m = best_m + m';
        
        % Have we converged yet?
        % [1] for test for criteria
        if max(abs(m))<0.001
            keep_going = 0;
        end

        % Give some feedback as to how the convergence is shaping up
        disp(num2str(best_m))
        
        counter = counter + 1;
    end

