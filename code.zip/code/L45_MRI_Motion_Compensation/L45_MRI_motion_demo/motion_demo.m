%% MRI Motion Demonstration
% CS 473 / CM 473 / CS 673
warning off;

%% Read in an image to play with
f = imread('t1.jpg'); % 256x256 image
f = double( f(:,:,1) ); % converts to floating-pt

% FFT (frequency domain = k-space)
F = ifftshift( fft2( fftshift(f) ) );

% t1 and t2 are the phase encodes before which the
%  2 motions occur.  ie. the patient moves right
% before phase encode t1, and again right before
% phase encode t2.
t1 = 126;
t2 = 140;

% Copy motionless portion of k-space (before ts(1))
Fcontrib = zeros(size(F));
Fcontrib(1:(t1-1),:) = F(1:(t1-1),:);
fcontrib_recon = ifftshift( ifft2( fftshift(Fcontrib) ) );

% Allocate k-space arrays to store moved portions of
% k-space.
F2contrib = zeros(size(F)); % Between 1st and 2nd motion
F3contrib = zeros(size(F)); % After 2nd motion

%% Motion corrupted MRI
figure(1);
thetas = (-10:1:10) + 0.2;
entrpy = zeros(size(thetas));

counter = 0;

% We'll try a bunch of movements of different sizes
for theta = thetas

    % Motion at t1 is a rotation by theta
    f2 =  MyAffine(f, p2m([0 0 theta 0 0 0]), 'cubic', 'centred');
    F2 =  ifftshift( fft2( fftshift(f2) ) ); % k-space
    F2contrib(t1:(t2-1),:) = F2(t1:(t2-1),:); % extract portion between t1 and t2
    % Reconstruct that portion
    f2contrib_recon = ifftshift( ifft2( fftshift(F2contrib) ) );

    % Motion at t2 is an r-translation by theta/2
    f3 =  MyAffine(f, p2m([0 0 theta 0 theta 0]), 'cubic', 'centred');
    F3 =  ifftshift( fft2( fftshift(f3) ) ); % k-space
    F3contrib(t2:end,:) = F3(t2:end,:); % extract portion from t2 on
    % Reconstruct that portion
    f3contrib_recon = ifftshift( ifft2( fftshift(F3contrib) ) );

    % Recorded k-space is the combination of the 3 parts above
    S = Fcontrib + F2contrib + F3contrib;
    s = ifftshift( ifft2( fftshift(S) ) ); % reconstruct

    % Display output
    subplot(2,2,1); imshow(real(fcontrib_recon),[]); title('Before t1');
    subplot(2,2,2); imshow(real(f2contrib_recon),[]); title('t1 to t2');
    subplot(2,2,3); imshow(real(f3contrib_recon),[]); title('After t2');
    subplot(2,2,4); imshow(real(s),[0 255]); title('Motion-corrupted');
    drawnow;
    
    h = hist(real(s(:)),0:4:255);
    h = h / numel(s);
    mask = h==0;
    counter = counter + 1;
    entrpy(counter) = -sum(h.*log(h+mask));
    
    disp([num2str(theta) ', ' num2str(entrpy(counter))]);
end

figure;
plot(thetas, entrpy);
xlabel('Motion amount');
ylabel('Entropy');

