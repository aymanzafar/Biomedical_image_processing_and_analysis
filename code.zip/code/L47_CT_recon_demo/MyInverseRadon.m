% function f = MyInverseRadon(p, theta, dims)
%
%   CT reconstruction function.
%   p is the input Radon Transform
%   theta is a vector of theta values at which the projections were
%   acquired
%   dims is a 2-vector holding the dimensions of the output image
%
function [f] = MyInverseRadon(p, theta, dims)

    [detector thetas] = size(p);

    accumulator = zeros(detector, detector);
    detector_ctr = floor( (detector+1) / 2 );
    %T = p2m([0 0 0 detector_ctr detector_ctr 0]);

    %f = zeros(dims);
    f_ctr = floor( (dims+1) / 2 );

    % Filter all the projections
    if 1
        ramp = abs( (1:(detector))' - detector_ctr );
        P = fftshift(fft(ifftshift(p)));
        p_filt = fftshift( ifft( ifftshift(P.*repmat(ramp,1,thetas) ) ) );
        p = real(p_filt);
    end
    
    % Loop through all the projections in our Radon Transform
    
    %hWaitBar = waitbar(0, 'Please wait...');


    for k = 1:1:size(theta,2)
        % Backproject...
        smear = repmat(p(:,k)', detector, 1);
        
        % ... along the direction of the gantry when the projection was
        % collected.
        %smear = MyAffine(smear, p2m([0 0 theta(1,k) 0 0 0]), 'linear','centred');
        smear = imrotate(smear, theta(1,k), 'bilinear', 'crop');
        accumulator = accumulator + smear;
        
        imshow(accumulator, []);
        pause(0.1);

        %waitbar( k / size(theta,2) );
    end


    %close( hWaitBar );

    f = circshift(accumulator, f_ctr - detector_ctr);
    f = f(1:dims(1), 1:dims(2));
