
% Fourier Projection Theorem demonstration script.

close all;

% Read in a sample image
f = imread('ct.jpg');
f = double(f(:,:,1));

%% Show input image
subplot(2,2,1);
imshow(f,[]);

%% Project down onto horizontal (c-) axis
px = sum(f);
subplot(2,2,3);
plot(px);
axis tight;

%% 2D Fourier Transform of f
F = fftshift( fft2(f) ); % put DC in centre just for visualization
subplot(2,2,2);
Fnice = log(abs(F)+1);
imshow(Fnice, []);

%% Extract 1D subspace from 2D Fourier Transform
ctr = GetCentre(F);
Fx = F(ctr(1),:);
subplot(2,2,4);
plot(log(abs(Fx)+1));
axis tight;

%% Annotate to show relationships
annotation('arrow',[0.45 0.55], [1 1]*0.75);
annotation('textbox', [0.45 0.75 0.1, 0.05], 'String', '2D FT', 'EdgeColor', 'none');

annotation('arrow', [1 1]*0.75, [0.55 0.45]);
annotation('textbox', [0.75 0.5 0.2, 0.05], 'String', '1D subspace', 'EdgeColor', 'none');

annotation('arrow', [1 1]*0.3, [0.55 0.45]);
annotation('textbox', [0.3 0.5 0.2, 0.05], 'String', 'Project', 'EdgeColor', 'none');

annotation('arrow',[0.55 0.47], [1 1]*0.25);
annotation('textbox', [0.46 0.26 0.1, 0.05], 'String', '1D IFT', 'EdgeColor', 'none');

%% More graphics

[R theta] = radon(f, 0:179);
figure;
imshow(R',[]);
imwrite(R'/max(R(:)), 'ct_radon_transpose.jpg', 'JPEG', 'Quality', 100);

imwrite(Fnice/max(Fnice(:)), 'fft2_of_ct.jpg', 'JPEG', 'Quality', 100);

