
% CT Reconstruction demonstration script.

% Read in a sample Radon Transform
R = double(imread('ct_data.tiff'));

figure(1);
imshow(R, []);

%%
% These are the thetas used when I created the Radon Transform
theta = 0:2:178;

N = 256;

% Alternatively, you can have Matlab compute the Radon Transform of
% an image of your choosing.  Below I use the Shepp-Logan phantom, but you
% could use any image.
%{
f = imread('ct.jpg');
f = double( f(:,:,1) );
theta = 0:1:179;
R = radon(f, theta);
%}

% Animated of filtered back-projection
%tic; [g2] = MyInverseRadon(R, theta, [N N]); toc

%pause;

% Matlab's built-in iradon
tic; [g2] = iradon(R, theta); toc
%tic; [g3] = iradon_speedy(R, theta); toc

figure;
subplot(1,2,1), imshow(R, []);
subplot(1,2,2), imshow(g2,[]);