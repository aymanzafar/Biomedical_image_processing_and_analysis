function g = MyPad(f, margin)
% g = MyPad(f, margin)
%
%  Pads the image f so that <margin> pixels are added to
%  all sides.

    pad_vec = margin * ones([1 length(size(f))]);

    g = padarray(f, pad_vec);

end

