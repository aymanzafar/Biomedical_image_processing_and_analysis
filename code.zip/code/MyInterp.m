% function y = MyInterp(f, x, method)
%
%  Interpolate an array f.
%
%  Input:
%    f is a 2D or 3D array (image or volume)
%    x is a 2-vector or 3-vector
%    method is either 'nearest' or 'linear'
%
%  Output:
%    y is the interpolation value of f at location x
%
%    If x is outside f, then the return value is 0.
%    eg. if f is a 10x15 pixel image, then
%        x=[0.9 4.8] and x=[3.7 15.1] are both outside f
%
%%%% [9] marks total
function y = MyInterp(f, x, method)

    dims = size(f);
    if length(dims)==2
        dims = [dims 1];
        x = [x(1) x(2) 1];
    end

    % [1] for checking if x is inside dataset
    if min(x)>=1 && x(1)<=dims(1) && x(2)<=dims(2) && x(3)<=dims(3)
        
        switch lower(method)
            
            case 'nearest'
                %%% [2] marks total for the nearest method
                
                a = round(x); % [1] for rounding coords
                
                % [1] for reading value
                if dims(3)==1
                    y = f(a(1),a(2));
                else
                    y = f(a(1), a(2), a(3));
                end
                
            case 'linear'
                %%%% [5] marks total for the linear method
                a = floor(x);
                
                % [1] Take care of case when a is the last sample (we need to
                % avoid trying to sample f beyond that).
                a = min(a,reshape(dims,size(a))-ones(size(a)));
                da = x - a;
                
                if dims(3)==1
                    % [2] for 2D linear interp
                    y =   (1-da(1))*(1-da(2)) * f(a(1),a(2)) ...
                        +   da(1)  *(1-da(2)) * f(a(1)+1,a(2)) ...
                        + (1-da(1))*  da(2)   * f(a(1),a(2)+1) ...
                        +   da(1)  *  da(2)   * f(a(1)+1,a(2)+1);
                else
                    % [2] for 3D linear interp
                    y =   (1-da(1))*(1-da(2))*(1-da(3)) * f(a(1)  ,a(2)  ,a(3)  ) ...
                        + (1-da(1))*da(2)    *(1-da(3)) * f(a(1)  ,a(2)+1,a(3)  ) ...
                        + da(1)    *da(2)    *(1-da(3)) * f(a(1)+1,a(2)+1,a(3)  ) ...
                        + da(1)    *(1-da(2))*(1-da(3)) * f(a(1)+1,a(2)  ,a(3)  ) ...
                        + (1-da(1))*(1-da(2))*da(3)     * f(a(1)  ,a(2)  ,a(3)+1) ...
                        + (1-da(1))*da(2)    *da(3)     * f(a(1)  ,a(2)+1,a(3)+1) ...
                        + da(1)    *da(2)    *da(3)     * f(a(1)+1,a(2)+1,a(3)+1) ...
                        + da(1)    *(1-da(2))*da(3)     * f(a(1)+1,a(2)  ,a(3)+1);
                end
                
        end % of switch statement
        
    else
        % [1] for handling the case where x is outside the image
        y = 0;
    end
    
    
    
    