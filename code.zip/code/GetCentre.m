%function ctr = GetCentre(f)
%
% Returns the centre of the image as a row-vector in the
% form [centre_row centre_col].  The centre pixel is defined
% as
%    ctr = floor( size(f) / 2 ) + 1;
%
function ctr = GetCentre(f)

    ctr = floor( size(f) / 2 ) + 1;
    %ctr = ceil( (size(f)+1) / 2 );
    
    % Was
    %    ctr = floor( (size(f)+1) / 2 );
    % Changed Feb. 10, 2009.
