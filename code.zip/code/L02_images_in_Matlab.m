%% Lesson 02 - Images in Matlab

% (C) 2013 Jeff Orchard
%     University of Waterloo

%% Read in an image

g = 0;


%% Display only the red channel



%% Read in a graylevel image

f = 0;

% What are the dimensions?


% A colon ":" means "all".
% eg. M(:,3) means all of the 3rd column
% eg. M(1,:) means all of the 1st row
% eg. f(:,:,5) means all of the 5th plane (channel)
%
% Also, M(:) puts all the elements of M into a single column

% == Extract only one channel from f ==
%f = ;

% Display the image


