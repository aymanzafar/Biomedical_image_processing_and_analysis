%% Lesson 03 - Spatial Transformations

% (C) 2013 Jeff Orchard
%     University of Waterloo

%% Create two transformations using homogeneous coordinates.

% P1 : Rotates 30 degrees
% P2 : Translates by [2 ; 1]

% Note: cosd and sind are cosine and sine for degrees (not radians)

P1 = 0;
 
P2 = 0;

  
%% Composition of those two

Ptotal = 0;

%% Create another transform

% P3 : rotates by 45 degrees, then translates by [-1 ; -1]

% The line below is not correct.  Fix it.
P3 = 0

%% Compose the result with another transform

% Fix the line below.
P_all_three = 0



