function g = MyCrop(f, margin)
% g = MyCrop(f, margin)
%
%  Crops the image f so that <margin> pixels are removed from
%  all sides.

    g = f((margin+1):(end-margin),(margin+1):(end-margin));

end

