% function [dphidr, dphidc]= UpwindGrad(phi, V)
%
%   phi is the level-set embedding function
%   V is the speed function (must be same size as V)
%
%   dphidr and dphidc are the row and column derivatives, computed using
%          upwinding.
%
% Marking scheme
%  [6 marks total] (see below)
%
function [dphidr, dphidc]= UpwindGrad(phi, V)

    % forward differencing
    % Shift I to LEFT by 1; brings I(:,j+1) to I(:,j)
    % [1 mark]
    drf = circshift(phi, [-1 0]) - phi;
    dcf = circshift(phi, [0 -1]) - phi; %r-axis is positive-down

    % backward differencing
    % Shift I to RIGHT by 1; brings I(:,j-1) to I(:,j)
    % [1 mark]
    drb = phi - circshift(phi, [1 0]);
    dcb = phi - circshift(phi, [0 1]); %y-axis is positive-down


    % [1]
    Dr_plus = max(drf,0) + min(drb,0);
    Dr_minus = min(drf,0) + max(drb,0);
    
    % [1] 
    Dc_plus = max(dcf,0) + min(dcb,0);
    Dc_minus = min(dcf,0) + max(dcb,0);

    % [2] 
    dphidr = (V<=0).*Dr_plus + (V>0).*Dr_minus;
    dphidc = (V<=0).*Dc_plus + (V>0).*Dc_minus;


