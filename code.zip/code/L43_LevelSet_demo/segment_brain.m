% =====================
% --- Assignment 5  ---
% -- LEVELSET method --
% =====================

% [4] marks total

close all;

% Read in the image
I = imread('brain.jpg');
I = double( I(:,:,1) );

%{
J = zeros(size(I));
vv = 0:20;
J(vv+125,vv+315) = fliplr(I(vv+212,vv+122));
J = MyGaussianBlur(J,0.5);
I = I + J;
%}

% Initialization of Active Contour
% Build the initial embedding function, phi.
% It's just an upward-opening cone sunken down 180 so that its
% radius at the zero level set is 180 pixels.
% [2] for sensible phi
ctr = floor( (size(I)+1) / 2 );
[X Y] = meshgrid((1:size(I,1))-ctr(1), (1:size(I,2))-ctr(2));
phi = realsqrt(X.^2 + Y.^2) - 180;

% Could also use a paraboloid.  Also, could blur this initial
% phi... that's OK.


% [1] Call the Levelset function
figure(1);
phi_final = LevelSet(I, phi);



% [1] Display final results
figure(1);
imshow(I, []);
hold on;
contour(phi_final,[0 0],'y','LineWidth',2);
hold off;

figure(2);
surf(phi_final, 'LineStyle', 'none');
colormap jet;
caxis auto;
