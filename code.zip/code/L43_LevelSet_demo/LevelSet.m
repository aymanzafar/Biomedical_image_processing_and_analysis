% function phi_final = LevelSet(I, phi) 
%
%   I is image to segment
%   phi is the initial embedding function (must be same size as I)
%
%   phi_final is the final embedding function, where the boundary of the
%   segmented region corresponds to the zero-crossing of the embedding
%   function.
%
% Marking scheme
%  [9 marks total] (see below)
%  
function phi_final = LevelSet(I, phi) 

    delta_t = 0.2;
    dispInterval = 10;
    inflate = -1; % -1 for deflate, +1 for inflate
    
    
    %=====================================
    % Speed function
    
    % [1] Image gradient
    [Vc Vr] = gradient(I); % Returns [dIdx, dIdy]
    Vr = - Vr; % reverse y-axis to get r-axis
    
    % [1] Gradient magnitude (squared, in my case)
    V = realsqrt(Vr.^2 + Vc.^2);
    % V = (Vr.^2 + Vc.^2); % also an option

    % Calculate the speed function from the image gradient.  As we approach
    % a large gradient, the speed function approaches 0.  For small
    % gradients, the speed function approaches 1 (unity).
    % [1] for choosing function type (see options below)
    % [1] for choosing proper sign (sign can also be set in update equation)
    Vn = inflate * 1./ (1+V); % One option
    %Vn = - exp(-V); % Anohter option
    
    
    
    % Set up a few incidental parameters
    diff = 1e300;
    old_segment_area = numel(I);
    counter = dispInterval;
    t = 0;

    
    
    %=====================================
    % Loop
    
    % I'm not fussy about the stopping criterion.  A fixed number of
    % iterations is OK with me.
    while diff>delta_t*20
        
        % Increment counter and time variable
        t = t + delta_t;
        counter = counter + 1;

        
        % [1] Call UpwindGrad: Calculates the gradient of phi using upwinding
        [dphidr dphidc] = UpwindGrad(phi, Vn);

        % [1] Gradient magnitude
        % Make sure it's not gradient magnitude squared (need sqrt)
        phi_grad = realsqrt( dphidr.^2 + dphidc.^2 );

        % [2] Update equation
        %  - make sure delta_t is there
        %  - OK if they also included curvature term (1 + epsilon*K)
        %  - sign of 2nd term should eval to positive
        %    (ie. in my case, Vn is negative)
        phi_final = phi - delta_t*Vn.*phi_grad;

        
        % Test to see if we should stop
        segment_area = sum( phi_final(:)<=0 );
        diff = abs( segment_area - old_segment_area );
        old_segment_area = segment_area;
        
        % [1] Display intermittent results
        if counter > dispInterval
            counter = 0;
            if 1
                hold off;
                pause(0.001);
                imshow(I, []);
                hold on;
                contour(phi,[0 0],'y','LineWidth',2);
            else
                surf(phi, 'LineStyle', 'none');
                colormap jet;
                caxis auto;
            end
            title(['t = ' num2str(t) ]);
            drawnow;
        end
        
        phi = phi_final; % Re-use phi for next iteration
        
    end
    

        
