%
% function [g thetas] = LogPolarResamp(f, freq)
%
% f is input image
% freq is either omitted, or one of 'single', or 'double'
%    indicating how frequently to sample in the angular
%    direction.
%      - if a number, degrees per sample
%      - 'single' is once for every outer pixel (default)
%      - 'double' is twice for every outer pixel
%
% g holds the log-polar resampling
% thetas is an array that stores the angular sampling (ie. what angles
%     were sampled in the polar resampling)
%
function [g thetas] = PolarResamp(f, freq)

    if nargin<2
        freq = 'single';
    end
    
    % Used to be
    % ctr = floor(size(f)/2);
    % But changed for NL-means rotation on Dec. 20, 2007
    [rows cols channels] = size(f);
    ctr = floor([rows cols]/2+1);
    
    T = maketform('custom',2,2,@tinyCart2Pol,@tinyPol2Cart, ctr );
    %T = maketform('custom',2,2,@myCart2Pol,@myPol2Cart, floor((size(f)+1)/2) );
    
    % Find maximum radius
    rmax = min( floor( ([rows cols]-1) / 2 ) ) - 1;
    
    if isnumeric(freq)==1
        samples_per_degree = 1 / freq;
    elseif strcmp(freq,'single')
        samples_per_degree = pi*rmax / 180;
    elseif strcmp(freq,'double')
        samples_per_degree = 2 * ceil( pi*rmax / 180 );
    else
        samples_per_degree = 1;
    end
    angles = ceil( 360 * samples_per_degree );
    theta_step = 360 / angles; %1 / samples_per_degree;
    thetas = linspace(0, 360-theta_step, angles);

    if length(size(f))==2
        g = imtransform(f, T, 'bicubic', ...
                  'UData', [1 cols], 'VData', [1 rows], ...
                  'XData', [360 theta_step], 'YData', [1 log(rmax)], ...
                  'Size', [rmax+1 angles] );
                  %'XYScale', [dtheta 1]);
                  %'XData', [0 359], 'YData', [ceil(sqrt((size(f,1)/2)^2+(size(f,2)/2)^2)) 0]);
    else
        %g = zeros(size(f,1),size(f,2),size(f,3));
        for chan = 1:size(f,3)
            g(:,:,chan) = imtransform(f(:,:,chan), T, 'bicubic', ...
                      'UData', [1 cols], 'VData', [1 rows], ...
                      'XData', [360 theta_step], 'YData', [0 rmax], ...
                      'Size', [rmax+1 angles] );
                      %'XYScale', [dtheta 1]);
                      %'XData', [0 359], 'YData', [ceil(sqrt((size(f,1)/2)^2+(size(f,2)/2)^2)) 0]);
        end
    end
    

          
              
              
function p = tinyCart2Pol(x, T)

    ctr = T.tdata;
    
    [t r] = cart2pol(x(:,1)-ctr(2), x(:,2)-ctr(1));
    
    p = [t*180/pi log(r)];
          
          
    
    
function X = tinyPol2Cart(p, T)

    ctr = T.tdata;
    
    [x y] = pol2cart(p(:,1)/180*pi, exp(p(:,2)));
    
    x(:) = x(:) + ctr(2);
    y(:) = y(:) + ctr(1);
    
    X = [x y];
          
          