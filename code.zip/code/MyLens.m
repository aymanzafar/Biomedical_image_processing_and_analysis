% function g = MyLens(f, p, method)
%
%  Perform a deformation to an image.
%
%  Input:
%    f is an input (graylevel) image
%    p is a scalar parameter that specifies the amount of
%      deformation (0 for none)
%    method is one of 'nearest' or 'linear', and specifies
%      the interpolation method
%
%  Output:
%    g is a graylevel image the same size as f
%
%  To run it, try
%   >> f = imread('cameraman.tif');
%   >> g = MyLens(f, -1);
%   >> imshow(g,[]);
%
% Marking scheme
% 2 for any region that is magnified or shrunken
% 2 for creating a displacement field
% 2 for symmetry of "lens"
% 1 for readable code
%
%%%% [7] marks total
function g = MyLens(f, p, method)

    dims = size(f);
    
    row_disp = zeros(dims);
    col_disp = zeros(dims);

    % Use a Gaussian to create the displacement field
    % (Could also call my Gaussian function.)
    Gaussian = fspecial('gaussian', dims,60);

    % The gradient of the Gaussian gives us the
    % actual displacement directions.
    [dcol drow] = gradient(-Gaussian.^2);

    % Scale the vectors so that they give the
    % desired effect.
    dcol = p * dcol / max(dcol(:)) * 40;
    drow = p * drow / max(drow(:)) * 40;
    
    % drow stores row displacements
    % dcol stores column displacements
    
    g = zeros(dims);

    % Loop over all pixels
    for col = 1:dims(1)
        for row = 1:dims(2)
            
            % Apply the displacement to the pixel coords
            y = [row+drow(row,col) col+dcol(row,col)];
            
            % Call MyInterp to get the pixel intensity
            g(row, col) = MyInterp(f, y, method);
        end
    end

