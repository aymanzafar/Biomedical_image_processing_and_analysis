%
% function dfdx = MyDerivative(f, ax)
%
% Computes derivative of f with respect to its <ax> motion parameter.
% The value of ax determines which motion paramerter the derivative
% is taken with respect to.
% In particular:
%      ax = 1 :  with respect to rotation about the row axis
%      ax = 2 :  with respect to rotation about the column axis
%      ax = 3 :  with respect to rotation about the slice axis
%      ax = 4 :  with respect to row index
%      ax = 5 :  with respect to column index
%      ax = 6 :  with respect to slice index
%

% ==== Marking Scheme ====
% Total marks [8] (see comments for distibution)
%
function dfdx = MyDerivative(f, ax)

    dfdx = zeros(size(f));
    ndims = length(size(f));
    delta = 1.5; % theta step
        
    switch ax
        
        case 1
            % rotation about r-axis
            % [1] for rotation about CENTRE of image
            M = p2m([delta 0 0 0 0 0]); 
            Minv = p2m([-delta 0 0 0 0 0]); 
            dfdx = ( MyAffine(f, M, 'linear','centred') - MyAffine(f, Minv, 'linear','centred') ) / (2*delta);
            % [1] for using theta-step of 1.5 degrees
            % [1] for using central differencing
            % [1] for proper denominators (2*delta)
            % Be forgiving about the sign of the rotational derivatives.
        case 2
            % rotation about c-axis
            M = p2m([0 delta 0 0 0 0]); 
            Minv = p2m([0 -delta 0 0 0 0]); 
            dfdx = ( MyAffine(f, M, 'linear','centred') - MyAffine(f, Minv, 'linear','centred') ) / (2*delta);
        case 3
            % rotation about s-axis
            M = p2m([0 0 delta 0 0 0]); 
            Minv = p2m([0 0 -delta 0 0 0]); 
            dfdx = ( MyAffine(f, M, 'linear','centred') - MyAffine(f, Minv, 'linear','centred') ) / (2*delta);
        case 4       
            % r-derivative
            dfdx(1,:,:) = f(1,:,:) - f(2,:,:); % Top row (forward diff)
            dfdx(end,:,:) = f(end-1,:,:) - f(end,:,:); % Bottom row (backward diff)
            dfdx(2:(end-1), :) = ( f(1:(end-2),:) - f(3:end,:) ) / 2; % Central diff
            % [1] for forward differencing
            % [1] for backward differencing
            % [1] for central differencing numerator
            % [1] for central differencing denominator
        case 5
            % c-derivative
            % Even without the 3rd index, it handles multiple slices.
            dfdx(:,1,:) = f(:,1,:) - f(:,2,:); % Left col
            dfdx(:,end,:) = f(:,end-1,:) - f(:,end,:); % Right col
            dfdx(:,2:(end-1),:) = ( f(:,1:(end-2),:) - f(:,3:end,:) ) / 2;

        case 6
            % s-derivative
            dfdx(:,:,1) = f(:,:,1) - f(:,:,2); % First slice
            dfdx(:,:,end) = f(:,:,end-1) - f(:,:,end); % Last slice
            dfdx(:,:,2:(end-1)) = ( f(:,:,1:(end-2)) - f(:,:,3:end) ) / 2;
            
    end

      